public class Main {

	public static void main(String[] args) {
		Interpreter i = new Interpreter();
		while(true){
			i.cmdInterpret();
		}

	}

}
